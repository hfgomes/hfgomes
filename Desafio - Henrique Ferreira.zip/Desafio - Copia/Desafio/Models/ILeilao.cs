﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Desafio.Models
{
    public interface ILeilao
    {
        IEnumerable<Leilao> GetAllItensLeilao();
        void AddItensLeilao(Leilao itensLeilao);
        void UpdateItensLeilao(Leilao itensLeilao);
        Leilao GetItensLeilao(int? ID);
        void DeleteItensLeilao(int? ID);
    }
}
