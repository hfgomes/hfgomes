﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Desafio.Models
{
    public class LeilaoDAL : ILeilao
    {
        string connectionString = @"Data Source=SPON010115238\SQLEXPRESS;Initial Catalog=LeilaoTOTVS;Integrated Security=True;";

        public void AddItensLeilao(Leilao itensLeilao)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string comandoSQL = "Insert into ItensLeilao (nome_leilao,valorInicial,dataAbertura,usado, dataTermino) Values (@nomeLeilao,@valor,@dataAbertura,@usado,@dataTermino)";
                SqlCommand cmd = new SqlCommand(comandoSQL, con);

                //adicionando
                cmd.Parameters.AddWithValue("@ID", SqlDbType.BigInt);
                cmd.Parameters.AddWithValue("@nomeLeilao", itensLeilao.nomeLeilao);
                cmd.Parameters.AddWithValue("@valor", itensLeilao.valorInicial);
                cmd.Parameters.AddWithValue("@dataAbertura", DateTime.Now);
                cmd.Parameters.AddWithValue("@usado", itensLeilao.usado);
                cmd.Parameters.AddWithValue("@dataTermino", itensLeilao.dataTermino);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public void DeleteItensLeilao(int? ID)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string comandoSQL = "Delete from ItensLeilao where ID = @ID";
                SqlCommand cmd = new SqlCommand(comandoSQL, con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", ID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public IEnumerable<Leilao> GetAllItensLeilao()
        {
            //instancia objeto.
            List<Leilao> lstLeilao = new List<Leilao>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string comandoSQL = "SELECT * FROM ItensLeilao";
                SqlCommand cmd = new SqlCommand(comandoSQL, con);
                cmd.CommandType = CommandType.Text;

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Leilao itensLeilao = new Leilao();

                    itensLeilao.ID = Convert.ToInt32(rdr["ID"]);
                    itensLeilao.nomeLeilao = rdr["nome_leilao"].ToString();
                    itensLeilao.valorInicial = Convert.ToDecimal(rdr["valorInicial"]);
                    itensLeilao.dataAbertura = Convert.ToDateTime(rdr["dataAbertura"]);
                    itensLeilao.usado = Convert.ToInt32(rdr["usado"]);
                    itensLeilao.dataTermino = Convert.ToDateTime(rdr["dataTermino"]);

                    lstLeilao.Add(itensLeilao);
                }
                con.Close();
            }
            return lstLeilao;
        }

        public Leilao GetItensLeilao(int? ID)
        {
            Leilao itensLeilao = new Leilao();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string comandoSQL = "SELECT * FROM ItensLeilao WHERE ID = " + ID;
                SqlCommand cmd = new SqlCommand(comandoSQL, con);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    itensLeilao.ID = Convert.ToInt32(rdr["ID"]);
                    itensLeilao.nomeLeilao = rdr["nome_leilao"].ToString();
                    itensLeilao.valorInicial = Convert.ToDecimal(rdr["valorInicial"]);
                    itensLeilao.dataAbertura = Convert.ToDateTime(rdr["dataAbertura"]);
                    itensLeilao.usado = Convert.ToInt32(rdr["usado"]);
                    itensLeilao.dataTermino = Convert.ToDateTime(rdr["dataTermino"]);
                }
                return itensLeilao;
            }
        }

        public void UpdateItensLeilao(Leilao itensLeilao)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string comandoSQL = "Update ItensLeilao set nome_leilao = @NomeLeilao, valorInicial = @Valor, dataAbertura = @dataAbertura, usado = @usado, dataTermino = @dataTermino where ID = @ID";

                SqlCommand cmd = new SqlCommand(comandoSQL, con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@ID", itensLeilao.ID);
                cmd.Parameters.AddWithValue("@nomeLeilao", itensLeilao.nomeLeilao);
                cmd.Parameters.AddWithValue("@usado", itensLeilao.usado);
                cmd.Parameters.AddWithValue("@valor", itensLeilao.valorInicial);
                cmd.Parameters.AddWithValue("@dataAbertura", DateTime.Now);
                cmd.Parameters.AddWithValue("@dataTermino", itensLeilao.dataTermino);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}
