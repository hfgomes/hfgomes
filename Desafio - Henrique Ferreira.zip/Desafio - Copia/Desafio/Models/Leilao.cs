﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Desafio.Models
{
    public class Leilao
    {
        [Key]
        [Display(Name = "Codigo")]
        public int ID { get; set; }

        [Required(ErrorMessage = "O Nome do Leilão é obrigatório")]
        [Display(Name = "Nome")]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,40}$", ErrorMessage = "Números e caracteres especiais não são permitidos no nome.")]
        public string nomeLeilao { get; set; }

        [Required(ErrorMessage = "É necessário definir se o item é usado")]
        [Display(Name = "Usado")]
        public int usado { get; set; }

        [Required]
        [Display(Name = "Valor")]
        [Range(0, 999999999999.99, ErrorMessage = "Informe um valor maior que zero")]
        [DisplayFormat(DataFormatString = "{0:###,##0.00}", ApplyFormatInEditMode = true)]
        public decimal valorInicial { get; set; }

        [Required]
        [Display(Name = "Data de Abertura")]
        public DateTime dataAbertura { get; set; }

        [Required(ErrorMessage = "Informe a data de término desse leilão")]
        [Display(Name = "Data de Término")]
        public DateTime dataTermino { get; set; }
    }
}
