﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Desafio.Models;
using Microsoft.AspNetCore.Mvc;

namespace Desafio.Controllers
{
    public class LeilaoController : Controller
    {
        private readonly ILeilao _itens;

        public LeilaoController(ILeilao itens)
        {
            _itens = itens;
        }

        public IActionResult Index()
        {
            List<Leilao> lista = new List<Leilao>();
            lista = _itens.GetAllItensLeilao().ToList();
            return View(lista);
        }

        [HttpGet]
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Leilao detalhes = _itens.GetItensLeilao(id);
            if (detalhes == null)
            {
                return NotFound();
            }
            return View(detalhes);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind] Leilao create)
        {
            if (ModelState.IsValid)
            {
                _itens.AddItensLeilao(create);
                return RedirectToAction("Index");
            }
            return View(create);
        }

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Leilao edit = _itens.GetItensLeilao(id);
            if (edit == null)
            {
                return NotFound();
            }
            return View(edit);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind]Leilao edit)
        {
            if (id != edit.ID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _itens.UpdateItensLeilao(edit);
                return RedirectToAction("Index");
            }
            return View(edit);
        }

        [HttpGet]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Leilao delete = _itens.GetItensLeilao(id);
            if (delete == null)
            {
                return NotFound();
            }
            return View(delete);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int? id)
        {
            _itens.DeleteItensLeilao(id);
            return RedirectToAction("Index");
        }
    }
}